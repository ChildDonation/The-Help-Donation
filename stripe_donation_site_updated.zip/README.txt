
INSTRIKSYON:

1. Ouvri terminal oswa CMD.
2. Mete sa a:
   cd chemin_kote_dosye_a
3. Enstale depandans yo:
   npm install
4. Mete Stripe API key ou:
   Ranplase 'sk_test_YOUR_SECRET_KEY' ak kle sekrè Stripe ou nan server.js
5. Kouri app la:
   npm start
6. Ale sou http://localhost:4242 pou teste donasyon an.

N.B.: Ou ka chanje montan an ($10) oswa mete Success/Cancel URL ou.
